package ar.org.centro8.curso.especialidad.web.server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.ServletComponentScan;

@SpringBootApplication
@ServletComponentScan()		
public class ServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServerApplication.class, args);

		/*
			para iniciar el servidor, se hace desde una terminal bash o gitbash
			sh mvnw spring-boot:run
		
		*/

	}

}
