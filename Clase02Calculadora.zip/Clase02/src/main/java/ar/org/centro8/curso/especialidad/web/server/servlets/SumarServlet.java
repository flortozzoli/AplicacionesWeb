package ar.org.centro8.curso.especialidad.web.server.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(name = "sumarservlet", urlPatterns = "/sumarServlet")
public class SumarServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/plain");
        try (PrintWriter out=response.getWriter()) {
            int nro1=Integer.parseInt(request.getParameter("nro1"));
            int nro2=Integer.parseInt(request.getParameter("nro2"));
            int resultado=nro1+nro2;
            out.println(resultado);
        } catch (Exception e) {
            System.out.println(e);
        }
    }

}
