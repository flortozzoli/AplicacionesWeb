package ar.org.centro8.curso.especialidad.web.server.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(name = "loginservlet", urlPatterns = "/loginServlet")
public class LoginServlet extends HttpServlet{

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        try (PrintWriter out=response.getWriter()){
            out.println("<h1>No se puede enviar parámetros por GET</h1>");
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        try (PrintWriter out=response.getWriter()){
            String user=request.getParameter("user");
            String pass=request.getParameter("pass");
            if(
                user!=null && !user.isEmpty() && pass!=null && !pass.isEmpty() &&
                user.equals("root") && pass.equals("123")
            ){
                out.println("<h1>Bienvenido al Sistema</h1>");
            }else{
                out.println("<h1>Error de ingreso</h1>");
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    
}
